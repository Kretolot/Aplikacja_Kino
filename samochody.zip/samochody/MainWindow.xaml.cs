﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace samochody
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnZarzadzaj_Click(object sender, RoutedEventArgs e)
        {
            ZarzadzajWindow okno = new ZarzadzajWindow();
            okno.ShowDialog();
        }

        private void btnWypozyczenia_Click(object sender, RoutedEventArgs e)
        {
            WypozyczeniaWindow okno = new WypozyczeniaWindow();
            okno.ShowDialog();
        }

        private void btnPrzeglad_Click(object sender, RoutedEventArgs e)
        {
            PrzegladWindow okno = new PrzegladWindow();
            okno.ShowDialog();
        }
    }
}