﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using Npgsql;

namespace samochody
{
    public partial class PrzegladWindow : Window
    {
        string connStr = "Host=localhost;Username=postgres;Password=postgres;Database=samochody";

        public PrzegladWindow()
        {
            InitializeComponent();
            LoadTables();
        }

        private void BtnPowrot_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void BtnOdswiez_Click(object sender, RoutedEventArgs e)
        {
            LoadTables();
        }

        private void LoadTables()
        {
            LoadWypozyczone();
            LoadDostepne();
        }

        private void LoadWypozyczone()
        {
            using var conn = new NpgsqlConnection(connStr);
            conn.Open();

            string sql = @"SELECT k.imie || ' ' || k.nazwisko AS klient,
                                  k.nr_tel AS telefon,
                                  p.marka, p.model, p.nr_rejestracyjny AS rejestracja, p.vin
                           FROM pojazdy p
                           LEFT JOIN klienci k ON p.klient_id = k.id
                           WHERE p.status = 'wypozyczony'
                           ORDER BY k.nazwisko;";

            using var da = new NpgsqlDataAdapter(sql, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dgWypozyczone.ItemsSource = dt.DefaultView;
        }

        private void LoadDostepne()
        {
            using var conn = new NpgsqlConnection(connStr);
            conn.Open();

            string sql = @"SELECT marka, model, nr_rejestracyjny AS rejestracja, vin, rocznik, pojemnosc, przebieg
                           FROM pojazdy
                           WHERE status = 'dostepny'
                           ORDER BY marka;";

            using var da = new NpgsqlDataAdapter(sql, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dgDostepne.ItemsSource = dt.DefaultView;
        }
    }
}
