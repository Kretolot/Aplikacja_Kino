﻿using Npgsql;
using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Npgsql;

namespace samochody
{
    // MODELE DANYCH
    public class Klient
    {
        public int Id { get; set; }
        public string Imie { get; set; }
        public string Nazwisko { get; set; }
        public string Plec { get; set; }
        public DateTime? DataUr { get; set; }
        public string NrTel { get; set; }
        public string Adres { get; set; }
    }

    public class Pojazd
    {
        public int Id { get; set; }
        public string Marka { get; set; }
        public string Model { get; set; }
        public string Vin { get; set; }
        public string NrRejestracyjny { get; set; }
        public int Rocznik { get; set; }
        public decimal Pojemnosc { get; set; }
        public int Przebieg { get; set; }
        public string Status { get; set; }
    }

    public partial class ZarzadzajWindow : Window
    {
        private ObservableCollection<Klient> klienci = new();
        private ObservableCollection<Pojazd> pojazdy = new();
        private Klient selectedKlient;
        private Pojazd selectedPojazd;

        // <-- TU WPISZ SWÓJ CONNECTION STRING DO POSTGRESQL -->
        private string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=postgres;Database=samochody";

        public ZarzadzajWindow()
        {
            InitializeComponent();

            dgKlienci.ItemsSource = klienci;
            dgPojazdy.ItemsSource = pojazdy;

            LoadKlienci();
            LoadPojazdy();
        }

        // ===================== MENU =====================
        private void Menu_Klienci_Click(object sender, RoutedEventArgs e)
        {
            gridKlienci.Visibility = Visibility.Visible;
            gridPojazdy.Visibility = Visibility.Collapsed;
        }

        private void Menu_Pojazdy_Click(object sender, RoutedEventArgs e)
        {
            gridKlienci.Visibility = Visibility.Collapsed;
            gridPojazdy.Visibility = Visibility.Visible;
        }

        private void BtnPowrot_Click(object sender, RoutedEventArgs e) => this.Close();

        // ===================== KLienci =====================
        private void LoadKlienci()
        {
            klienci.Clear();
            using var conn = new NpgsqlConnection(connectionString);
            conn.Open();
            using var cmd = new NpgsqlCommand("SELECT * FROM klienci ORDER BY id", conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                klienci.Add(new Klient
                {
                    Id = reader.GetInt32(reader.GetOrdinal("id")),
                    Imie = reader.GetString(reader.GetOrdinal("imie")),
                    Nazwisko = reader.GetString(reader.GetOrdinal("nazwisko")),
                    Plec = reader.IsDBNull(reader.GetOrdinal("plec")) ? null : reader.GetString(reader.GetOrdinal("plec")),
                    DataUr = reader.GetDateTime(reader.GetOrdinal("data_ur")),
                    NrTel = reader.GetString(reader.GetOrdinal("nr_tel")),
                    Adres = reader.IsDBNull(reader.GetOrdinal("adres")) ? "" : reader.GetString(reader.GetOrdinal("adres"))
                });
            }
        }

        private void BtnDodajKlienta_Click(object sender, RoutedEventArgs e)
        {
            using var conn = new NpgsqlConnection(connectionString);
            conn.Open();
            string sql = "INSERT INTO klienci (imie, nazwisko, plec, data_ur, nr_tel, adres) VALUES (@imie,@nazwisko,@plec,@data,@tel,@adres)";
            using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("imie", txtImie.Text);
            cmd.Parameters.AddWithValue("nazwisko", txtNazwisko.Text);
            cmd.Parameters.AddWithValue("plec", cmbPlec.SelectedIndex == 0 ? "M" : "K");
            cmd.Parameters.AddWithValue("data", dpDataUr.SelectedDate ?? DateTime.Now);
            cmd.Parameters.AddWithValue("tel", txtTelefon.Text);
            cmd.Parameters.AddWithValue("adres", txtAdres.Text);
            cmd.ExecuteNonQuery();
            LoadKlienci();
            WyczyscKlient();
        }

        private void BtnAktualizujKlienta_Click(object sender, RoutedEventArgs e)
        {
            if (selectedKlient == null) return;
            using var conn = new NpgsqlConnection(connectionString);
            conn.Open();
            string sql = "UPDATE klienci SET imie=@imie, nazwisko=@nazwisko, plec=@plec, data_ur=@data, nr_tel=@tel, adres=@adres WHERE id=@id";
            using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("imie", txtImie.Text);
            cmd.Parameters.AddWithValue("nazwisko", txtNazwisko.Text);
            cmd.Parameters.AddWithValue("plec", cmbPlec.SelectedIndex == 0 ? "M" : "K");
            cmd.Parameters.AddWithValue("data", dpDataUr.SelectedDate ?? DateTime.Now);
            cmd.Parameters.AddWithValue("tel", txtTelefon.Text);
            cmd.Parameters.AddWithValue("adres", txtAdres.Text);
            cmd.Parameters.AddWithValue("id", selectedKlient.Id);
            cmd.ExecuteNonQuery();
            LoadKlienci();
            WyczyscKlient();
        }

        private void BtnUsunKlienta_Click(object sender, RoutedEventArgs e)
        {
            if (selectedKlient == null) return;
            using var conn = new NpgsqlConnection(connectionString);
            conn.Open();
            string sql = "DELETE FROM klienci WHERE id=@id";
            using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("id", selectedKlient.Id);
            cmd.ExecuteNonQuery();
            LoadKlienci();
            WyczyscKlient();
        }

        private void DgKlienci_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedKlient = dgKlienci.SelectedItem as Klient;
            if (selectedKlient != null)
            {
                txtImie.Text = selectedKlient.Imie;
                txtNazwisko.Text = selectedKlient.Nazwisko;
                cmbPlec.SelectedIndex = selectedKlient.Plec == "M" ? 0 : 1;
                dpDataUr.SelectedDate = selectedKlient.DataUr;
                txtTelefon.Text = selectedKlient.NrTel;
                txtAdres.Text = selectedKlient.Adres;
                btnAktualizujKlienta.IsEnabled = true;
                btnUsunKlienta.IsEnabled = true;
            }
            else
            {
                btnAktualizujKlienta.IsEnabled = false;
                btnUsunKlienta.IsEnabled = false;
            }
        }

        private void WyczyscKlient()
        {
            txtImie.Text = "";
            txtNazwisko.Text = "";
            cmbPlec.SelectedIndex = -1;
            dpDataUr.SelectedDate = null;
            txtTelefon.Text = "";
            txtAdres.Text = "";
            dgKlienci.SelectedIndex = -1;
            selectedKlient = null;
            btnAktualizujKlienta.IsEnabled = false;
            btnUsunKlienta.IsEnabled = false;
        }

        private void BtnWyczyscKlient_Click(object sender, RoutedEventArgs e) => WyczyscKlient();

        // ===================== Pojazdy =====================
        private void LoadPojazdy()
        {
            pojazdy.Clear();
            using var conn = new NpgsqlConnection(connectionString);
            conn.Open();
            using var cmd = new NpgsqlCommand("SELECT * FROM pojazdy ORDER BY id", conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                pojazdy.Add(new Pojazd
                {
                    Id = reader.GetInt32(reader.GetOrdinal("id")),
                    Marka = reader.GetString(reader.GetOrdinal("marka")),
                    Model = reader.GetString(reader.GetOrdinal("model")),
                    Vin = reader.GetString(reader.GetOrdinal("vin")),
                    NrRejestracyjny = reader.GetString(reader.GetOrdinal("nr_rejestracyjny")),
                    Rocznik = reader.GetInt32(reader.GetOrdinal("rocznik")),
                    Pojemnosc = reader.GetDecimal(reader.GetOrdinal("pojemnosc")),
                    Przebieg = reader.GetInt32(reader.GetOrdinal("przebieg")),
                    Status = reader.GetString(reader.GetOrdinal("status"))
                });
            }
        }

        private void BtnDodajPojazd_Click(object sender, RoutedEventArgs e)
        {
            using var conn = new NpgsqlConnection(connectionString);
            conn.Open();
            string sql = @"INSERT INTO pojazdy (marka, model, vin, nr_rejestracyjny, rocznik, pojemnosc, przebieg, status)
                           VALUES (@marka,@model,@vin,@nr,@rocznik,@pojemnosc,@przebieg,'dostepny')";
            using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("marka", txtMarka.Text);
            cmd.Parameters.AddWithValue("model", txtModel.Text);
            cmd.Parameters.AddWithValue("vin", txtVin.Text);
            cmd.Parameters.AddWithValue("nr", txtNrRej.Text);
            cmd.Parameters.AddWithValue("rocznik", int.TryParse(txtRocznik.Text, out int r) ? r : 0);
            cmd.Parameters.AddWithValue("pojemnosc", decimal.TryParse(txtPojemnosc.Text, out decimal p) ? p : 0);
            cmd.Parameters.AddWithValue("przebieg", int.TryParse(txtPrzebieg.Text, out int km) ? km : 0);
            cmd.ExecuteNonQuery();
            LoadPojazdy();
            WyczyscPojazd();
        }

        private void BtnAktualizujPojazd_Click(object sender, RoutedEventArgs e)
        {
            if (selectedPojazd == null) return;
            using var conn = new NpgsqlConnection(connectionString);
            conn.Open();
            string sql = @"UPDATE pojazdy SET marka=@marka, model=@model, nr_rejestracyjny=@nr, rocznik=@rocznik, 
                           pojemnosc=@pojemnosc, przebieg=@przebieg, status=@status WHERE id=@id";
            using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("marka", txtMarka.Text);
            cmd.Parameters.AddWithValue("model", txtModel.Text);
            cmd.Parameters.AddWithValue("nr", txtNrRej.Text);
            cmd.Parameters.AddWithValue("rocznik", int.TryParse(txtRocznik.Text, out int r) ? r : 0);
            cmd.Parameters.AddWithValue("pojemnosc", decimal.TryParse(txtPojemnosc.Text, out decimal p) ? p : 0);
            cmd.Parameters.AddWithValue("przebieg", int.TryParse(txtPrzebieg.Text, out int km) ? km : 0);
            cmd.Parameters.AddWithValue("status", selectedPojazd.Status);
            cmd.Parameters.AddWithValue("id", selectedPojazd.Id);
            cmd.ExecuteNonQuery();
            LoadPojazdy();
            WyczyscPojazd();
        }

        private void BtnUsunPojazd_Click(object sender, RoutedEventArgs e)
        {
            if (selectedPojazd == null) return;
            using var conn = new NpgsqlConnection(connectionString);
            conn.Open();
            string sql = "DELETE FROM pojazdy WHERE id=@id";
            using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("id", selectedPojazd.Id);
            cmd.ExecuteNonQuery();
            LoadPojazdy();
            WyczyscPojazd();
        }

        private void DgPojazdy_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedPojazd = dgPojazdy.SelectedItem as Pojazd;
            if (selectedPojazd != null)
            {
                txtMarka.Text = selectedPojazd.Marka;
                txtModel.Text = selectedPojazd.Model;
                txtVin.Text = selectedPojazd.Vin;
                txtVin.IsReadOnly = true;
                txtNrRej.Text = selectedPojazd.NrRejestracyjny;
                txtRocznik.Text = selectedPojazd.Rocznik.ToString();
                txtPojemnosc.Text = selectedPojazd.Pojemnosc.ToString();
                txtPrzebieg.Text = selectedPojazd.Przebieg.ToString();
                btnAktualizujPojazd.IsEnabled = true;
                btnUsunPojazd.IsEnabled = true;
            }
            else
            {
                WyczyscPojazd();
            }
        }

        private void WyczyscPojazd()
        {
            txtMarka.Text = "";
            txtModel.Text = "";
            txtVin.Text = "";
            txtVin.IsReadOnly = false;
            txtNrRej.Text = "";
            txtRocznik.Text = "";
            txtPojemnosc.Text = "";
            txtPrzebieg.Text = "";
            dgPojazdy.SelectedIndex = -1;
            selectedPojazd = null;
            btnAktualizujPojazd.IsEnabled = false;
            btnUsunPojazd.IsEnabled = false;
        }

        private void BtnWyczyscPojazd_Click(object sender, RoutedEventArgs e) => WyczyscPojazd();
        private void CmbFiltrStatus_SelectionChanged(object sender, SelectionChangedEventArgs e) { /* opcjonalny filtr */ }
    }
}
