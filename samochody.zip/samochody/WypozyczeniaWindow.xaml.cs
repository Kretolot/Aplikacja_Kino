﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Npgsql;

namespace samochody
{
    public partial class WypozyczeniaWindow : Window
    {
        string connStr = "Host=localhost;Username=postgres;Password=postgres;Database=samochody";

        public WypozyczeniaWindow()
        {
            InitializeComponent();
            LoadClients();
            LoadAvailableCars();
            LoadRentedCars();
        }

        private void BtnPowrot_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        // === POBIERANIE DANYCH ===
        private void LoadClients()
        {
            using var conn = new NpgsqlConnection(connStr);
            conn.Open();

            using var cmd = new NpgsqlCommand("SELECT id, imie || ' ' || nazwisko FROM klienci", conn);
            using var da = new NpgsqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            cmbKlient.ItemsSource = dt.DefaultView;
            cmbKlient.DisplayMemberPath = " ?column?";
            cmbKlient.SelectedValuePath = "id";
        }

        private void LoadAvailableCars()
        {
            using var conn = new NpgsqlConnection(connStr);
            conn.Open();

            using var cmd = new NpgsqlCommand(
                "SELECT id, marka || ' ' || model || ' (' || nr_rejestracyjny || ')' AS opis FROM pojazdy WHERE status='dostepny'",
                conn);
            using var da = new NpgsqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            cmbPojazd.ItemsSource = dt.DefaultView;
            cmbPojazd.DisplayMemberPath = "opis";
            cmbPojazd.SelectedValuePath = "id";
        }

        private void LoadRentedCars()
        {
            using var conn = new NpgsqlConnection(connStr);
            conn.Open();

            using var cmd = new NpgsqlCommand(
                "SELECT p.id, marka || ' ' || model || ' (' || nr_rejestracyjny || ')' AS opis " +
                "FROM pojazdy p WHERE status='wypozyczony'",
                conn);
            using var da = new NpgsqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            cmbPojazdZwrot.ItemsSource = dt.DefaultView;
            cmbPojazdZwrot.DisplayMemberPath = "opis";
            cmbPojazdZwrot.SelectedValuePath = "id";
        }

        // === WYPOŻYCZENIE ===
        private void BtnWypozycz_Click(object sender, RoutedEventArgs e)
        {
            if (cmbKlient.SelectedValue == null || cmbPojazd.SelectedValue == null)
            {
                MessageBox.Show("Musisz wybrać klienta i pojazd");
                return;
            }

            using var conn = new NpgsqlConnection(connStr);
            conn.Open();

            using var cmd = new NpgsqlCommand(
                "UPDATE pojazdy SET klient_id=@k, status='wypozyczony' WHERE id=@p",
                conn);
            cmd.Parameters.AddWithValue("@k", cmbKlient.SelectedValue);
            cmd.Parameters.AddWithValue("@p", cmbPojazd.SelectedValue);
            cmd.ExecuteNonQuery();

            MessageBox.Show("Wypożyczyłeś pojazd");
            LoadAvailableCars();
            LoadRentedCars();
        }

        // === ZWROT ===
        private void BtnZwroc_Click(object sender, RoutedEventArgs e)
        {
            if (cmbPojazdZwrot.SelectedValue == null)
            {
                MessageBox.Show("Wybierz pojazd");
                return;
            }

            using var conn = new NpgsqlConnection(connStr);
            conn.Open();

            using var cmd = new NpgsqlCommand(
                "UPDATE pojazdy SET klient_id=NULL, status='dostepny' WHERE id=@p",
                conn);
            cmd.Parameters.AddWithValue("@p", cmbPojazdZwrot.SelectedValue);
            cmd.ExecuteNonQuery();

            MessageBox.Show("Zwrócileś pojazd");
            LoadAvailableCars();
            LoadRentedCars();
        }

        private void CmbKlient_SelectionChanged(object sender, SelectionChangedEventArgs e) { }
        private void CmbPojazdZwrot_SelectionChanged(object sender, SelectionChangedEventArgs e) { }
    }
}
